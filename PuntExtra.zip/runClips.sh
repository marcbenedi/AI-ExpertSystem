#!/bin/bash

./mount.sh

echo "Script ./mount.sh executat"
echo ""

echo "Executant clips"
echo ""
clips < clipsInstructions.input
